$(document).ready({

});

function openSignInRegister(){
    $('#signinRegisterPopup').fadeIn();
    console.log("This triggered");
}